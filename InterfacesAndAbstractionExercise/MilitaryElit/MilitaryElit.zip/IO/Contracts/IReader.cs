﻿namespace MilitaryElit.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
