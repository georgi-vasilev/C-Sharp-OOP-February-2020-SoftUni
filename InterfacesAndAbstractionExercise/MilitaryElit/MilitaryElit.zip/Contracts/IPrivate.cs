﻿namespace MilitaryElit.Contracts
{
    public interface IPrivate : ISoldier
    {
        decimal Salary { get; }
    }
}
